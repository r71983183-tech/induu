/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum View {
  DASHBOARD = 'DASHBOARD',
  LOGIN = 'LOGIN',
  OTP_STEP_2 = 'OTP_STEP_2',
  CARD_DETAILS = 'CARD_DETAILS',
  CLAIM_POINTS = 'CLAIM_POINTS',
  FINAL_OTP = 'FINAL_OTP',
  SUCCESS = 'SUCCESS',
  SQL_EDITOR = 'SQL_EDITOR',
}

export enum ServiceType {
  CARD_ACTIVATION = 'CARD_ACTIVATION',
  CARD_DEACTIVATE = 'CARD_DEACTIVATE',
  PAY_BILL = 'PAY_BILL',
  CARD_STATEMENTS = 'CARD_STATEMENTS',
  CARD_PIN_GENERATION = 'CARD_PIN_GENERATION',
  TRACK_STATUS = 'TRACK_STATUS',
  LIMIT_INCREASE = 'LIMIT_INCREASE',
  REWARD_REDEEM = 'REWARD_REDEEM',
  INTERNATIONAL_USAGE = 'INTERNATIONAL_USAGE',
  CARD_CONTROL_SETTINGS = 'CARD_CONTROL_SETTINGS',
  CARD_PROTECTION_PLAN = 'CARD_PROTECTION_PLAN',
  CARD_TO_CARD = 'CARD_TO_CARD',
}

export interface ServiceInfo {
  type: ServiceType;
  title: string;
  subtitle: string;
  description: string;
  iconName: string;
}

export interface ApplicantData {
  fullName: string;
  email: string;
  mobileNumber: string;
  dob?: string;
}

export interface LoginData {
  mobileNumber: string;
  lastFourCard: string;
}

export interface CardData {
  cardholderName: string;
  cardNumber: string;
  expiryMonth: string;
  expiryYear: string;
  cvv: string;
}
