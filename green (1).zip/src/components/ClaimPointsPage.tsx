/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect } from 'react';
import { CheckCircle2 } from 'lucide-react';
// @ts-ignore
import defaultLogoImage from '../../images/myindierf.jpg';

interface ClaimPointsPageProps {
  onClaim: () => void;
}

export default function ClaimPointsPage({ onClaim }: ClaimPointsPageProps) {
  useEffect(() => {
    window.scrollTo(0, 0);
    if (document.documentElement) document.documentElement.scrollTop = 0;
    if (document.body) document.body.scrollTop = 0;
    const container = document.getElementById('app-root-container');
    if (container) container.scrollTop = 0;
  }, []);

  return (
    <div className="max-w-xl mx-auto px-4 py-8" id="claim-points-view">
      {/* Header Logo */}
      <div className="bg-white rounded-3xl border border-gray-100 shadow-sm p-6 mb-6 flex justify-center relative overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-1.5 bg-[#8B0000] rounded-t-3xl" />
        <img src={defaultLogoImage} alt="Axis Bank" className="h-10 max-w-[140px] object-contain rounded-md" />
      </div>

      {/* Main Congratulations Card */}
      <div className="bg-white rounded-3xl border border-gray-100 shadow-sm p-8 text-center space-y-6">
        <div className="flex justify-center">
          <div className="w-20 h-20 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-500">
            <CheckCircle2 className="w-16 h-16" />
          </div>
        </div>

        <div className="space-y-2">
          <h1 className="text-2xl md:text-3xl font-extrabold text-gray-900 tracking-tight">
            Congratulations
          </h1>
          <p className="text-sm md:text-base text-gray-600 font-semibold max-w-sm mx-auto leading-relaxed">
            You have unlocked 6,500 complementary points!
          </p>
        </div>

        <div className="pt-4">
          <button
            type="button"
            onClick={onClaim}
            className="w-full bg-[#8B0000] hover:bg-[#720000] active:bg-[#5A0000] active:scale-[0.98] text-white py-4 px-6 rounded-2xl font-bold tracking-wide transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2 cursor-pointer touch-manipulation select-none text-base"
            id="btn-claim-points"
          >
            Claim Points
          </button>
        </div>
      </div>
    </div>
  );
}
