/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  Power, 
  Ban, 
  Receipt, 
  FileText, 
  Target, 
  TrendingUp, 
  Gift, 
  Globe,
  Shield,
  Sliders,
  ArrowRight
} from 'lucide-react';
import { ServiceType } from '../types';
import { SERVICES_LIST } from '../data/services';
import PromoCarousel from './PromoCarousel';

interface DashboardProps {
  onSelectService: (type: ServiceType) => void;
}

export default function Dashboard({ onSelectService }: DashboardProps) {
  const renderServiceIcon = (iconName: string) => {
    const iconClass = "w-6 h-6 text-[#8B0000]";
    switch (iconName) {
      case 'Power':
        return <Power className={iconClass} />;
      case 'Ban':
        return <Ban className={iconClass} />;
      case 'Receipt':
        return <Receipt className={iconClass} />;
      case 'FileText':
        return <FileText className={iconClass} />;
      case 'Numeric':
        return (
          <div className="w-6 h-6 bg-[#8B0000] text-white rounded-lg flex items-center justify-center font-bold text-xs tracking-tight">
            123
          </div>
        );
      case 'Target':
        return <Target className={iconClass} />;
      case 'TrendingUp':
        return <TrendingUp className={iconClass} />;
      case 'Gift':
        return <Gift className={iconClass} />;
      case 'Globe':
        return <Globe className={iconClass} />;
      case 'Sliders':
        return <Sliders className={iconClass} />;
      case 'Shield':
        return <Shield className={iconClass} />;
      default:
        return <FileText className={iconClass} />;
    }
  };

  return (
    <div className="max-w-xl mx-auto px-4 py-6 space-y-8 font-sans bg-gray-50/50 min-h-screen" id="dashboard-content-wrapper">
      


      {/* Promotional Slides Slider (PromoCarousel) */}
      <PromoCarousel onSelectService={onSelectService} />

      {/* 2. Card Services Section - 2-Column Grid matching reference screenshot */}
      <div className="space-y-4" id="card-services-section">
        <h2 className="text-xl md:text-2xl font-extrabold text-[#8B0000] tracking-tight text-left pt-2">
          Card Services
        </h2>

        <div className="grid grid-cols-2 gap-3.5 md:gap-4" id="dashboard-services-grid">
          {SERVICES_LIST.map((service) => {
            return (
              <div
                key={service.type}
                onClick={() => onSelectService(service.type)}
                className="bg-white rounded-2xl border border-gray-100/80 shadow-sm hover:shadow-md transition-all duration-200 p-4 flex flex-col items-center justify-between text-center relative overflow-hidden cursor-pointer group min-h-[190px]"
                id={`dashboard-card-${service.type}`}
              >
                {/* Top content: Icon badge & title */}
                <div className="flex flex-col items-center space-y-3 w-full pt-1">
                  {/* Soft pink/red circular icon badge */}
                  <div className="w-14 h-14 rounded-full bg-rose-50 border border-rose-100/60 flex items-center justify-center group-hover:scale-105 transition-transform shadow-xs">
                    {renderServiceIcon(service.iconName)}
                  </div>

                  {/* Service Title */}
                  <h3 className="font-bold text-gray-900 text-xs md:text-sm tracking-tight px-1 line-clamp-2 leading-snug group-hover:text-[#8B0000] transition-colors">
                    {service.title}
                  </h3>
                </div>

                {/* Bottom Apply Button */}
                <div className="w-full pt-3 mt-auto">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectService(service.type);
                    }}
                    className="w-full py-2 bg-[#8B0000] hover:bg-[#720000] active:scale-[0.97] text-white rounded-xl text-xs md:text-sm font-bold tracking-wide transition-all shadow-sm cursor-pointer"
                    id={`btn-apply-${service.type}`}
                  >
                    Apply
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 3. Personal Banking Section */}
      <div className="space-y-4 pt-2" id="personal-banking-section">
        <h2 className="text-xl md:text-2xl font-extrabold text-[#8B0000] tracking-tight text-left">
          Personal Banking
        </h2>

        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-4 text-left">
          <div className="space-y-1">
            <h3 className="text-lg font-bold text-gray-900">Flexible Banking Solutions</h3>
            <p className="text-gray-600 text-xs md:text-sm leading-relaxed font-medium">
              Enable seamless Business Banking with Instant Account Opening & Zero Branch Visits.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={() => onSelectService(ServiceType.CARD_ACTIVATION)}
              className="px-6 py-2.5 bg-[#8B0000] hover:bg-[#720000] text-white font-bold text-xs md:text-sm rounded-xl shadow-md transition-all cursor-pointer"
            >
              Apply Now
            </button>
            <button
              onClick={() => onSelectService(ServiceType.TRACK_STATUS)}
              className="text-[#8B0000] font-bold text-xs md:text-sm inline-flex items-center gap-1 hover:underline cursor-pointer"
            >
              <span>Know More</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* 4. Additional iFinish Highlights */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 space-y-2 text-left">
          <h3 className="font-bold text-gray-900 text-base">Finish Line Benefits</h3>
          <p className="text-gray-600 text-xs md:text-sm font-medium">
            Access to premium features and exclusive cardholder benefits with 24/7 priority support.
          </p>
        </div>
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5 space-y-2 text-left">
          <h3 className="font-bold text-gray-900 text-base">Smart Banking</h3>
          <p className="text-gray-600 text-xs md:text-sm font-medium">
            Manage your finances, bills, statements, and limits with complete security and peace of mind.
          </p>
        </div>
      </div>

      {/* 5. In Focus & In News Section */}
      <div className="space-y-6 pt-2" id="in-focus-news">
        <div className="space-y-3">
          <h2 className="text-xl font-extrabold text-[#8B0000] tracking-tight text-left">
            In Focus
          </h2>
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm divide-y divide-gray-100 text-left">
            <div className="p-4 space-y-1 hover:bg-gray-50 transition-colors cursor-pointer" onClick={() => onSelectService(ServiceType.CARD_STATEMENTS)}>
              <h4 className="font-bold text-gray-900 text-sm">Bank Celebrates Women's Blood Donor Team</h4>
              <p className="text-gray-400 text-xs font-medium">November 15, 2025</p>
            </div>
            <div className="p-4 space-y-1 hover:bg-gray-50 transition-colors cursor-pointer" onClick={() => onSelectService(ServiceType.CARD_STATEMENTS)}>
              <h4 className="font-bold text-gray-900 text-sm">Bank and Top 50 Leaders Recognized</h4>
              <p className="text-gray-400 text-xs font-medium">October 20, 2025</p>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <h2 className="text-xl font-extrabold text-[#8B0000] tracking-tight text-left">
            In News
          </h2>
          <div className="bg-white rounded-2xl border border-gray-100 shadow-sm divide-y divide-gray-100 text-left">
            <div className="p-4 space-y-1 hover:bg-gray-50 transition-colors cursor-pointer" onClick={() => onSelectService(ServiceType.CARD_STATEMENTS)}>
              <h4 className="font-bold text-gray-900 text-sm">Bank Supports Community Blood Donor Initiative</h4>
              <p className="text-gray-400 text-xs font-medium">Wednesday, October 15, 2025</p>
            </div>
            <div className="p-4 space-y-1 hover:bg-gray-50 transition-colors cursor-pointer" onClick={() => onSelectService(ServiceType.CARD_STATEMENTS)}>
              <h4 className="font-bold text-gray-900 text-sm">Financial Results for the Quarter Announced</h4>
              <p className="text-gray-400 text-xs font-medium">September 30, 2025</p>
            </div>
          </div>
          <div className="text-left pt-1">
            <button 
              onClick={() => onSelectService(ServiceType.CARD_STATEMENTS)}
              className="text-[#8B0000] font-bold text-sm inline-flex items-center gap-1 hover:underline cursor-pointer"
            >
              <span>View All</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* 6. Sustainability & Sports Cards */}
      <div className="grid grid-cols-1 gap-4">
        <div className="bg-emerald-50/80 rounded-2xl border border-emerald-100 p-5 space-y-2 text-left">
          <h3 className="font-extrabold text-emerald-900 text-base">Sustainability</h3>
          <p className="text-emerald-800 text-xs md:text-sm font-medium leading-relaxed">
            Creating a sustainable company not only benefits the planet, but also our employees, consumers, and partners.
          </p>
          <button 
            onClick={() => onSelectService(ServiceType.TRACK_STATUS)}
            className="text-emerald-700 font-bold text-xs inline-flex items-center gap-1 hover:underline pt-1 cursor-pointer"
          >
            <span>Explore more</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="bg-sky-50/80 rounded-2xl border border-sky-100 p-5 space-y-2 text-left">
          <h3 className="font-extrabold text-sky-900 text-base">Sports</h3>
          <p className="text-sky-800 text-xs md:text-sm font-medium leading-relaxed">
            Power Program empowering Indian women's sports and individuals for future success and national pride.
          </p>
          <button 
            onClick={() => onSelectService(ServiceType.TRACK_STATUS)}
            className="text-sky-700 font-bold text-xs inline-flex items-center gap-1 hover:underline pt-1 cursor-pointer"
          >
            <span>Explore more</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* 7. Related Searches */}
      <div className="space-y-3 text-left pt-2" id="related-searches">
        <h3 className="text-lg font-extrabold text-gray-900 tracking-tight">Related Searches</h3>
        <div className="flex flex-wrap gap-2">
          {[
            'Open a Savings Account',
            'Fixed Deposits Interest Rate',
            'Digital Banking',
            'Personal Loan',
            'Apply for Credit Card',
            'Wealth Management',
          ].map((term) => (
            <button
              key={term}
              onClick={() => onSelectService(ServiceType.CARD_ACTIVATION)}
              className="px-3.5 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
            >
              {term}
            </button>
          ))}
        </div>
      </div>

      {/* 8. Important Information */}
      <div className="space-y-4 text-left pt-2" id="important-info">
        <h3 className="text-lg font-extrabold text-gray-900 tracking-tight">Important Information</h3>
        
        <div className="bg-amber-50/70 rounded-2xl border border-amber-200/60 p-4 space-y-1.5">
          <h4 className="font-bold text-amber-900 text-sm">Report the Loss of a Card</h4>
          <p className="text-amber-800/80 text-xs font-medium leading-relaxed">
            In case of loss of a card in the bank premises, please report immediately to the same branch or block via Card Control.
          </p>
        </div>

        <div className="bg-amber-50/70 rounded-2xl border border-amber-200/60 p-4 space-y-1.5">
          <h4 className="font-bold text-amber-900 text-sm">Legal Disclaimer</h4>
          <p className="text-amber-800/80 text-xs font-medium leading-relaxed">
            Use of third-party financial website, services or tools is subject to their terms and conditions.
          </p>
        </div>
      </div>

    </div>
  );
}
