/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ChevronUp } from 'lucide-react';

interface AxisFooterProps {
  onOpenSqlEditor?: () => void;
}

export default function AxisFooter({ onOpenSqlEditor }: AxisFooterProps) {
  const [searchValue, setSearchValue] = useState('');

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchValue.trim()) {
      alert(`Searching for: ${searchValue}`);
      setSearchValue('');
    }
  };

  return (
    <footer className="w-full bg-[#7a1c22] text-white font-sans mt-12 py-8 px-4" id="axis-portal-footer">
      <div className="max-w-xl mx-auto space-y-6 text-center">
        
        {/* About Us */}
        <div className="space-y-2">
          <h3 className="font-bold text-lg md:text-xl border-b border-white/20 pb-2 inline-block px-8">About Us</h3>
          <div className="flex flex-wrap justify-center gap-x-6 gap-y-2 text-xs md:text-sm font-medium text-rose-100 pt-1">
            <span className="hover:underline cursor-pointer">Company</span>
            <span className="hover:underline cursor-pointer">Investor Relations</span>
            <span className="hover:underline cursor-pointer">Media & Brands</span>
            <span className="hover:underline cursor-pointer">Careers</span>
          </div>
        </div>

        {/* Initiatives */}
        <div className="space-y-2">
          <h3 className="font-bold text-lg md:text-xl border-b border-white/20 pb-2 inline-block px-8">Initiatives</h3>
          <div className="flex flex-wrap justify-center gap-x-6 gap-y-2 text-xs md:text-sm font-medium text-rose-100 pt-1">
            <span className="hover:underline cursor-pointer">CSR</span>
            <span className="hover:underline cursor-pointer">For Sports</span>
          </div>
        </div>

        {/* Other Sections */}
        <div className="space-y-3 pt-2">
          <div className="border-b border-white/20 pb-2 max-w-sm mx-auto">
            <h4 className="font-bold text-base md:text-lg cursor-pointer hover:underline">Calculators</h4>
          </div>
          <div className="border-b border-white/20 pb-2 max-w-sm mx-auto">
            <h4 className="font-bold text-base md:text-lg cursor-pointer hover:underline">Branch/ATM</h4>
          </div>
          <div className="border-b border-white/20 pb-2 max-w-sm mx-auto">
            <h4 className="font-bold text-base md:text-lg cursor-pointer hover:underline">Cyber Security</h4>
          </div>
          <div className="border-b border-white/20 pb-2 max-w-sm mx-auto">
            <h4 className="font-bold text-base md:text-lg cursor-pointer hover:underline">Mcxlus Operandi Cyber Crimes</h4>
          </div>
          <div className="border-b border-white/20 pb-2 max-w-sm mx-auto">
            <h4 className="font-bold text-base md:text-lg cursor-pointer hover:underline">Regulatory Disclosures</h4>
          </div>
        </div>

        {/* Search / Submit Form */}
        <form onSubmit={handleSearchSubmit} className="max-w-md mx-auto pt-3 flex bg-white rounded-xl overflow-hidden shadow-md">
          <input 
            type="text"
            value={searchValue}
            onChange={(e) => setSearchValue(e.target.value)}
            placeholder="Search..."
            className="flex-1 px-4 py-3 text-gray-800 text-sm focus:outline-none"
          />
          <button 
            type="submit"
            className="px-6 py-3 bg-[#7a1c22] hover:bg-[#62151a] text-white font-bold text-sm tracking-wide cursor-pointer transition-colors"
          >
            submit
          </button>
        </form>

        {/* DICGC Notice */}
        <div className="flex justify-center items-center gap-8 pt-4 text-xs font-semibold text-rose-200">
          <div className="flex items-center gap-2">
            <span>DICGC</span>
          </div>
          <div className="flex items-center gap-2">
            <span>DIcGC</span>
          </div>
        </div>

        {/* Registered Office Address */}
        <div className="text-[11px] md:text-xs text-rose-200/90 leading-relaxed font-medium pt-2 max-w-md mx-auto">
          Registered Office: 2401 Gen. Thimmayya Road (Cantonment), Pune 411 001. India. Tel: 020 26343201
        </div>

      </div>

      {/* Sticky Scroll to top button */}
      <button
        onClick={scrollToTop}
        className="fixed bottom-6 right-6 w-11 h-11 bg-white text-[#7a1c22] hover:bg-gray-100 rounded-2xl shadow-lg transition-transform hover:scale-105 cursor-pointer flex items-center justify-center active:scale-95 z-40"
        aria-label="Scroll to top"
        id="footer-scroll-top-btn"
      >
        <ChevronUp className="w-5 h-5 stroke-[2.5]" />
      </button>
    </footer>
  );
}
