/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ServiceType } from '../types';

interface PromoCarouselProps {
  onSelectService: (type: ServiceType) => void;
}

export default function PromoCarousel({ onSelectService }: PromoCarouselProps) {
  return (
    <div className="w-full relative overflow-hidden rounded-2xl shadow-md border border-sky-100 group cursor-pointer" onClick={() => onSelectService(ServiceType.CARD_ACTIVATION)}>
      <img 
        src="/assets/aistudio/WhatsApp_Image_2026-11-18_at_8.59.03_PM_c9d0db8d.jpeg" 
        alt="Winter Carnival Lifetime Free Credit Card" 
        className="w-full h-auto object-cover transform group-hover:scale-[1.01] transition-transform duration-300"
        referrerPolicy="no-referrer"
      />
    </div>
  );
}
