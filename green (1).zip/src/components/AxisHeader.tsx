/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ArrowLeft, Shield } from 'lucide-react';
import AxisLogo from './AxisLogo';
import { ServiceType } from '../types';

interface AxisHeaderProps {
  onBack?: () => void;
  showBack?: boolean;
  onMenuToggle?: () => void;
  showMenu?: boolean;
  isSecure?: boolean;
  onSelectService?: (type: ServiceType) => void;
  onLogin?: () => void;
}

export default function AxisHeader({
  onBack,
  showBack = false,
  onMenuToggle,
  showMenu = true,
  isSecure = false,
  onSelectService,
  onLogin,
}: AxisHeaderProps) {
  return (
    <div className="sticky top-0 z-30 flex flex-col" id="header-and-subheader-wrapper">
      {/* Primary Navigation Bar matching screenshot */}
      <header 
        className="bg-white border-b border-gray-100 py-3 px-4 md:px-6 flex items-center justify-between shadow-xs"
        id="axis-app-header"
      >
        <div className="flex items-center gap-3" id="header-left-section">
          {showBack && onBack ? (
            <button
              onClick={onBack}
              className="p-1.5 rounded-full hover:bg-rose-50 text-[#8B0000] transition-colors cursor-pointer"
              aria-label="Go back"
              id="header-back-button"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
          ) : null}
          
          <AxisLogo className="h-10 md:h-12" variant="color" />
        </div>

        <div className="flex items-center gap-3" id="header-right-section">
          {isSecure && (
            <div 
              className="flex items-center gap-1.5 bg-green-50 text-emerald-700 px-2.5 py-1 rounded-full text-xs font-semibold tracking-wider uppercase border border-emerald-100"
              id="secure-badge"
            >
              <Shield className="w-3.5 h-3.5 fill-emerald-100" />
              <span>100% SECURE</span>
            </div>
          )}

          {/* Login Button matching screenshot */}
          <button
            onClick={() => {
              if (onLogin) {
                onLogin();
              } else if (onSelectService) {
                onSelectService(ServiceType.CARD_ACTIVATION);
              } else if (onMenuToggle) {
                onMenuToggle();
              }
            }}
            className="px-5 py-2 bg-[#8B0000] hover:bg-[#720000] active:scale-95 text-white rounded-xl text-xs sm:text-sm font-extrabold tracking-wide shadow-sm transition-all cursor-pointer"
            id="header-login-btn"
          >
            Login
          </button>
        </div>
      </header>

      {/* Secure Banking Session Info Bar Strip */}
      <div 
        className="bg-[#ecf3f8] border-b border-sky-100/30 py-2 px-4 md:px-6 flex items-center justify-between text-[11px] md:text-xs text-[#4c6682] font-semibold tracking-tight"
        id="secure-banking-session-strip"
      >
        <div className="flex items-center gap-1.5" id="secure-strip-left">
          <span className="text-xs" role="img" aria-label="lock">🔒</span>
          <span>Secure Banking Session</span>
        </div>
        <div className="text-right font-medium text-slate-400" id="secure-strip-right">
          Last sync: Just now
        </div>
      </div>
    </div>
  );
}
