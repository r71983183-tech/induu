/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

// @ts-ignore
import axisBankLogoImage from '../../images/myindierf.jpg';

interface AxisLogoProps {
  className?: string;
  variant?: 'color' | 'white';
  showText?: boolean;
}

export function AxisLogoIcon({ className = "w-8 h-8", color = "#8B0000" }: { className?: string; color?: string }) {
  return (
    <img 
      src={axisBankLogoImage} 
      alt="Axis Bank Logo" 
      className={`object-contain ${className}`}
      id="axis-logo-icon-img"
      referrerPolicy="no-referrer"
    />
  );
}

export default function AxisLogo({ className = "h-8", variant = 'color', showText = false }: AxisLogoProps) {
  return (
    <div 
      className={`flex items-center gap-2.5 select-none ${className}`} 
      id="axis-logo-wrapper"
    >
      {/* Official Logo Photo provided by user */}
      <div className="flex-shrink-0 flex items-center justify-center h-full" id="axis-logo-icon-container">
        <img 
          src={axisBankLogoImage} 
          alt="Logo" 
          className="h-10 max-h-10 md:h-12 md:max-h-12 w-auto object-contain"
          id="axis-bank-photo-logo"
          referrerPolicy="no-referrer"
        />
      </div>
    </div>
  );
}
